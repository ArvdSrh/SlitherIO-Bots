
edited by test114514 (200bots.ga)

credit by Badplayer, Trap

-------------------------------------------------

node.js
https://nodejs.org/en/

tampermonkey (google chrome extention)
https://chrome.google.com/webstore/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo

u need to install node.js and tampermonkey
also add userscript to tampermonkey

how to run?
click run.bat and go to slither.io


contact us
http://200bots.ga/ 
or
https://discord.gg/jEug8C5